<?php

class Class_model extends CI_Model{

    public function salvarProduto($obj){
       $this->db->insert('Produto', $obj);  
       return "Inserido com sucesso!";

    }
    public function salvarUser($obj){
        $nome = $obj['nome'];
        $query = $this->db->query("SELECT * FROM usuario WHERE nome='".$nome."'");
        if ($query->result() != NULL){
            return NULL;
        }      
        else {
            $this->db->insert('usuario', $obj);   
            return "Inserido com sucesso!";            
        }

    }
    public function verificarUser($nome,$senha,$tipo_usuario){     
        $query = $this->db->get_where('usuario', array('nome'=>$nome, 'senha'=>$senha,'tipo_usuario'=>$tipo_usuario));
        return $query->row_array();
    }
    public function getall(){
        $query = $this->db->get('Produto');
        return $query;
    }
    public function excluir($cod){
        $table = array('Produto');
        $this->db->where('codigo',$cod);
        $this->db->delete($table);
    }
    public function update($obj){        
        $this->db->where('codigo',$obj['codigo']);
        $this->db->update('Produto', $obj);
    }
    public function select($obj){
        $tipo_operacao = $obj['tipo_operacao'];
        $query = $this->db->query("SELECT * FROM Produto WHERE tipo_operacao='".$tipo_operacao."'");
        return $query->result();        
        
    }      
}

?>
