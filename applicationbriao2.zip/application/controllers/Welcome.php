<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('array');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->model('Class_model','model');

	}
	public function index()
	{
	/*	$this->load->library('session');
		
		//restrict users to go back to login if session has been set
		if($this->session->userdata('user')){
			redirect('home');
		}
		else{
			$this->load->view('login_page');
		}
		*/
		$this->load->library('session');		
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
				$nome = $_POST['nome'];
				$senha = $_POST['senha'];
				$tipo_usuario = $_POST['tipo_usuario'];

				$data = $this->model->verificarUser($nome, $senha,$tipo_usuario);

				if($data){
					$_SESSION['tipo_usuario'] = $data['tipo_usuario'];
					$this->session->set_userdata('usuario', $data);
					return 	$this->load->view('listarProdutos');					
				}
				else{
					$this->session->set_flashdata('Usuário ou Senha incorretos');
				} 
		
		}
		else{
			$this->load->view('login');	
		}
	
	}
	public function salvarProduto(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){			
			$obj = array(
				'descricao' => $_POST['descricao'],
				'foto'  => $_FILES['foto']['name'],
				'quantidade'  => $_POST['quantidade'],				
				'palavraChave'  => $_POST['palavraChave'],			
				'preco'  => $_POST['preco'],
				'peso_produto'  =>$_POST['peso_produto']
				
			);		
			$this->model->salvarProduto($obj);	
			redirect('http://localhost/index.php/Welcome/listar');			
		}
		else {
			$this->load->view('inserirProduto');	
			
		}		
	}
	public function altera(){
		$this->load->view('alterar');		
	}
		
	public function alterar(){
		$obj = array(
			'codigo' => $_POST['cod'],			
			'descricao' => $_POST['descricao'],
			'foto'  => $_POST['foto']['name'],
			'bairro'  => $_POST['bairro'],			
			'preco'  => $_POST['preco'],
			'dormitorios'  =>$_POST['dormitorios'],
			'tipo_operacao'  => $_POST['tipo_operacao']
			
		);	
		$this->model->update($obj);			    		
		redirect('http://localhost/index.php/Welcome/listar');
		
	}
	public function consultar(){	
		$this->load->view('consultar');
		
	}		
	public function salvarConsulta(){
		$obj = array(
			'bairro' => $_POST['bairro'],
			'dormitorios'  =>$_POST['dormitorios'],
			'tipo_operacao'  => $_POST['tipo_operacao']
			
		);		
		$data['imoveis'] = $this->model->select($obj);
		$this->load->view('listar',$data);	
		
	}	
	public function listar(){
		$data['imoveis'] = $this->model->getall()->result();	
		$_SESSION['imoveis'] = $data['imoveis'];						
		$this->load->view('listar',$data);	
	}
	
	public function fpdf(){	
		/*print_r($_SESSION['imoveis'][0]->bairro);*/
		require_once("fpdf/fpdf.php");
		$pdf= new FPDF("L","pt","A4");	
		$pdf->AddPage();		
		foreach ($_SESSION['imoveis'] as $row){
			$pdf->SetFont('arial','B',12);
			$pdf->Cell(0,5,"Codigo: ".$row->codigo,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Descricao: ".$row->descricao,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Foto: ".$row->foto,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Bairro: ".$row->bairro,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Dormitorios: ".$row->dormitorios,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Preco: ".$row->preco,0,1,'L');
			$pdf->Ln(20);
			$pdf->Cell(0,5,"Tipo operacao: ".$row->tipo_operacao,0,1,'L');
			$pdf->Ln(20);
			$pdf->Ln(20);
			
		}
		$pdf->Output();		
	}
	
	public function deletar(){
		$cod = $_GET['cod'];
		$this->model->excluir($cod);
		redirect('http://localhost/index.php/Welcome/listar');
	}
}
